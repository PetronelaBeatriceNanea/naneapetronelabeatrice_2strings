#include <fstream>
#include <string.h>
#include <stdio.h>
using namespace std;
int main()
{
    char a[50];
    ifstream fin("text.in");
    fin.get(a,50);
    ofstream fout("text.out");
    for(int i=0;i<strlen(a);i++)
    {
        if(isdigit(a[i]))
        {
            fout<<a[i];
            if(isalpha(a[i+1]))
                fout<<endl;
        }
    }
    fin.close();
    fout.close();
}
